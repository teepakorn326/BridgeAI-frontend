const languageSelect = document.getElementById('language');
const apiUrlInput = document.getElementById('apiUrl');
const translateBtn = document.getElementById('translateBtn');
const saveBtn = document.getElementById('saveBtn');
const toggleBtn = document.getElementById('toggleBtn');
const linkBtn = document.getElementById('linkBtn');
const accountBody = document.getElementById('accountBody');
const statusEl = document.getElementById('status');

const { DEFAULT_API_BASE, DEFAULT_WEB_URL } = self.BRIDGE_CONFIG;

const LECTURE_URL_PATTERN = /echo360\.|coursera\.org|udemy\.com/;

// The panel runs in its own detached window, so `currentWindow:true`
// would return the panel itself. Scan all normal browser windows for
// a supported lecture tab instead.
async function findLectureTab() {
  const tabs = await chrome.tabs.query({ windowType: 'normal' });
  const matching = tabs.filter((t) => t.url && LECTURE_URL_PATTERN.test(t.url));
  if (matching.length === 0) return null;
  return matching.find((t) => t.active) || matching[0];
}

// Inject content.js into a lecture tab if the passive content_scripts
// injection missed it (happens after every extension reload).
async function ensureContentScript(tab) {
  try {
    await chrome.tabs.sendMessage(tab.id, { action: 'ping' });
  } catch {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      files: ['content.js'],
    });
    await chrome.scripting.insertCSS({
      target: { tabId: tab.id, allFrames: true },
      files: ['styles.css'],
    });
  }
}

// ── Settings ─────────────────────────────────────────────────────
chrome.storage.sync.get(['targetLang', 'apiUrl'], (data) => {
  if (data.targetLang) languageSelect.value = data.targetLang;
  apiUrlInput.value = data.apiUrl || DEFAULT_API_BASE;
});

languageSelect.addEventListener('change', () => {
  chrome.storage.sync.set({ targetLang: languageSelect.value });
});

apiUrlInput.addEventListener('change', () => {
  chrome.storage.sync.set({ apiUrl: apiUrlInput.value });
});

// ── Account state ────────────────────────────────────────────────
function renderAccount(auth) {
  const signedIn = !!(auth && auth.token && auth.user);
  if (signedIn) {
    accountBody.innerHTML = `<div class="email">${auth.user.email}</div>`;
    linkBtn.textContent = 'Sign out';
  } else {
    accountBody.innerHTML = '<span class="muted">Not signed in</span>';
    linkBtn.textContent = 'Sign in on web';
  }
  translateBtn.disabled = !signedIn;
  saveBtn.disabled = !signedIn;
  toggleBtn.disabled = !signedIn;
  if (!signedIn) setStatus('Sign in to use BridgeAI.', 'err');
  else if (statusEl.textContent === 'Sign in to use BridgeAI.') setStatus('', '');
}

function loadAuth() {
  chrome.storage.local.get(['auth'], ({ auth }) => renderAccount(auth));
}

loadAuth();

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.auth) renderAccount(changes.auth.newValue);
});

linkBtn.addEventListener('click', () => {
  chrome.storage.local.get(['auth'], ({ auth }) => {
    if (auth && auth.token) {
      chrome.runtime.sendMessage({ action: 'logout' }, () => {
        chrome.storage.local.remove('auth');
      });
      return;
    }
    chrome.tabs.create({ url: `${DEFAULT_WEB_URL}/login?next=/link-extension` });
  });
});

// ── Status helpers ───────────────────────────────────────────────
function setStatus(text, type) {
  statusEl.textContent = text;
  statusEl.className =
    type === 'ok' ? 'status-ok' : type === 'err' ? 'status-err' : 'status-loading';
}

// ── Progress bar ─────────────────────────────────────────────────
const progressEl = document.getElementById('progress');
const progressLabel = document.getElementById('progressLabel');
const progressPct = document.getElementById('progressPct');
const progressFill = document.getElementById('progressFill');
let progressTimer = null;
let progressValue = 0;
let progressStages = [];

function renderProgress() {
  const pct = Math.floor(progressValue);
  progressPct.textContent = pct + '%';
  progressFill.style.width = pct + '%';
  progressEl.setAttribute('aria-valuenow', String(pct));
  const stage = progressStages.find((s) => pct < s.until) || progressStages[progressStages.length - 1];
  if (stage) progressLabel.textContent = stage.label;
}

function startProgress(stages) {
  stopProgress();
  progressStages = stages && stages.length ? stages : [{ until: 100, label: 'Working…' }];
  progressValue = 1;
  progressEl.classList.add('active');
  setStatus('', '');
  renderProgress();
  // No creep timer — progress is driven by real events:
  //   extractionProgress → 0–20%
  //   translationProgress → 20–90%
  //   saveProgress → 95%
  //   finishProgress() → 100%
}

function finishProgress() {
  if (progressTimer) {
    clearInterval(progressTimer);
    progressTimer = null;
  }
  progressValue = 100;
  renderProgress();
  setTimeout(() => {
    progressEl.classList.remove('active');
  }, 400);
}

function stopProgress() {
  if (progressTimer) {
    clearInterval(progressTimer);
    progressTimer = null;
  }
  progressEl.classList.remove('active');
  progressValue = 0;
}

// Real progress driven by the content-script batch loop. Kills the creep
// timer so batch events alone determine the bar position.
function setRealProgress(pct) {
  if (progressTimer) {
    clearInterval(progressTimer);
    progressTimer = null;
  }
  // Never go backwards (batches can arrive slightly out of order).
  progressValue = Math.max(progressValue, Math.min(95, pct));
  renderProgress();
}

chrome.runtime.onMessage.addListener((msg) => {
  if (!msg || !progressEl.classList.contains('active')) return;

  if (msg.action === 'extractionProgress') {
    const { current, total } = msg;
    if (!total) return;
    // 0–20% reserved for extraction stages.
    setRealProgress((current / total) * 20);
    return;
  }

  if (msg.action === 'translationProgress') {
    const { current, total } = msg;
    if (!total) return;
    // 20–90% reserved for batch translation.
    setRealProgress(20 + (current / total) * 70);
    return;
  }

  if (msg.action === 'saveProgress') {
    // 90–99% reserved for the ingest/save round-trip (no intermediate signal).
    setRealProgress(95);
    return;
  }
});

// ── Translate ────────────────────────────────────────────────────
translateBtn.addEventListener('click', async () => {
  translateBtn.disabled = true;
  startProgress([
    { until: 30, label: 'Extracting transcript…' },
    { until: 70, label: 'Translating segments…' },
    { until: 100, label: 'Finalising subtitles…' },
  ]);

  try {
    const tab = await findLectureTab();
    if (!tab) {
      translateBtn.disabled = false;
      stopProgress();
      setStatus('Open an Echo360, Coursera, or Udemy lecture tab first.', 'err');
      return;
    }
    await ensureContentScript(tab);
    chrome.tabs.sendMessage(
      tab.id,
      {
        action: 'translate',
        targetLang: languageSelect.value,
        apiUrl: apiUrlInput.value,
      },
      (response) => {
        translateBtn.disabled = false;
        if (chrome.runtime.lastError) {
          stopProgress();
          setStatus('Could not reach the lecture page. Try reloading it.', 'err');
          return;
        }
        if (response && response.error) {
          stopProgress();
          setStatus('Error: ' + response.error, 'err');
        } else if (response && response.success) {
          finishProgress();
          setStatus(response.message || 'Subtitles ready!', 'ok');
        } else {
          stopProgress();
        }
      }
    );
  } catch (err) {
    translateBtn.disabled = false;
    stopProgress();
    setStatus('Error: ' + err.message, 'err');
  }
});

// ── Save to dashboard ────────────────────────────────────────────
saveBtn.addEventListener('click', async () => {
  saveBtn.disabled = true;
  startProgress([
    { until: 40, label: 'Capturing lecture…' },
    { until: 80, label: 'Translating segments…' },
    { until: 100, label: 'Saving to dashboard…' },
  ]);
  try {
    const tab = await findLectureTab();
    if (!tab) {
      saveBtn.disabled = false;
      stopProgress();
      setStatus('Open a supported lecture page first.', 'err');
      return;
    }
    await ensureContentScript(tab);
    chrome.tabs.sendMessage(
      tab.id,
      {
        action: 'capture',
        targetLang: languageSelect.value,
        apiUrl: apiUrlInput.value,
      },
      (response) => {
        saveBtn.disabled = false;
        if (chrome.runtime.lastError) {
          stopProgress();
          setStatus('Could not reach the lecture page. Try reloading it.', 'err');
          return;
        }
        if (response && response.error) {
          stopProgress();
          setStatus('Error: ' + response.error, 'err');
        } else if (response && response.success) {
          finishProgress();
          setStatus('Saved to your dashboard.', 'ok');
        } else {
          stopProgress();
        }
      }
    );
  } catch (err) {
    saveBtn.disabled = false;
    stopProgress();
    setStatus('Error: ' + err.message, 'err');
  }
});

// ── Toggle overlay ───────────────────────────────────────────────
toggleBtn.addEventListener('click', async () => {
  const tab = await findLectureTab();
  if (!tab) {
    setStatus('Open a supported lecture page (Echo360, Coursera, Udemy).', 'err');
    return;
  }
  await ensureContentScript(tab);
  chrome.tabs.sendMessage(tab.id, { action: 'toggle' }, (response) => {
    if (chrome.runtime.lastError) {
      setStatus('Could not reach the lecture page. Try reloading it.', 'err');
      return;
    }
    if (response) setStatus(response.visible ? 'Subtitles visible' : 'Subtitles hidden', 'ok');
  });
});
