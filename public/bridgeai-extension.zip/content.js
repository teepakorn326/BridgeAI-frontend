/**
 * BridgeAI Content Script — Bilingual Lecture Subtitles
 *
 * Runs on Echo360, Coursera, and Udemy lecture pages. Extracts transcript
 * from the video's text tracks or DOM, sends to BridgeAI backend for
 * translation, and renders a bilingual subtitle overlay synced to playback.
 */

(function () {
  'use strict';

  let translatedSegments = [];
  let overlayContainer = null;
  let overlayEN = null;
  let overlayTranslated = null;
  let overlayVisible = true;
  let videoElement = null;

  // In-memory caches so the user can click Translate or Save in any order
  // without redoing extraction or translation. Keyed on location.href so
  // SPA navigations naturally invalidate.
  let cachedRawSegments = null;
  let cachedRawKey = null;
  let cachedTranslatedKey = null; // `${location.href}|${targetLang}`

  function translatedCacheValid(targetLang) {
    return (
      translatedSegments &&
      translatedSegments.length > 0 &&
      cachedTranslatedKey === `${location.href}|${targetLang}`
    );
  }

  function rememberTranslatedSegments(targetLang) {
    cachedTranslatedKey = `${location.href}|${targetLang}`;
  }

  async function getRawSegments(providedSegments, video) {
    if (providedSegments && providedSegments.length > 0) return providedSegments;
    if (cachedRawSegments && cachedRawSegments.length > 0 && cachedRawKey === location.href) {
      console.log(`[BridgeAI] Reusing ${cachedRawSegments.length} cached raw segments`);
      return cachedRawSegments;
    }
    const segments = await extractTranscript(video);
    if (segments && segments.length > 0) {
      cachedRawSegments = segments;
      cachedRawKey = location.href;
    }
    return segments;
  }

  // ── Platform Detection ────────────────────────────────────────────

  function detectPlatform() {
    const host = location.hostname;
    if (host.includes('youtube.com') || host.includes('youtu.be')) return 'youtube';
    if (host.includes('echo360.')) return 'echo360';
    if (host.includes('coursera.org')) return 'coursera';
    if (host.includes('udemy.com')) return 'udemy';
    return 'generic';
  }

  const PLATFORM = detectPlatform();

  function extractYouTubeID() {
    try {
      const u = new URL(location.href);
      if (u.hostname.includes('youtu.be')) return u.pathname.slice(1) || null;
      const v = u.searchParams.get('v');
      if (v) return v;
      const parts = u.pathname.split('/').filter(Boolean);
      const i = parts.indexOf('embed');
      if (i >= 0 && parts[i + 1]) return parts[i + 1];
      const s = parts.indexOf('shorts');
      if (s >= 0 && parts[s + 1]) return parts[s + 1];
      return null;
    } catch {
      return null;
    }
  }

  // ── Transcript Extraction ─────────────────────────────────────────

  /**
   * Strategy 1: Extract from HTML5 TextTrack API (most reliable).
   */
  function extractFromTextTracks(video) {
    const tracks = video.textTracks;
    if (!tracks || tracks.length === 0) return null;

    for (let i = 0; i < tracks.length; i++) {
      const track = tracks[i];
      if (track.kind === 'captions' || track.kind === 'subtitles') {
        // Activate the track so cues get populated
        const prevMode = track.mode;
        track.mode = 'hidden';

        const cues = track.cues;
        if (cues && cues.length > 0) {
          const segments = Array.from(cues).map((cue) => ({
            start: cue.startTime,
            end: cue.endTime,
            text: cue.text.replace(/<[^>]*>/g, '').trim(), // strip HTML tags
          }));
          console.log(`[BridgeAI] Extracted ${segments.length} segments from TextTrack`);
          return segments;
        }

        track.mode = prevMode;
      }
    }
    return null;
  }

  /**
   * Strategy 2: Scrape Echo360 transcript panel DOM.
   *
   * Echo360 uses a ReactVirtualized list — only visible entries are in
   * the DOM. Each entry is:
   *   <dd title="8.41 min" data-test-component="Content">
   *     <span role="button">transcript text</span>
   *   </dd>
   *
   * We scroll through the virtualized list to collect all entries.
   */
  /**
   * Coursera transcript panel: rendered as a list of phrases with
   * <span class="rc-Phrase" data-ts="123.45">text</span> entries.
   */
  function extractFromCourseraDOM() {
    const phrases = document.querySelectorAll('[data-ts], .rc-Phrase');
    if (!phrases.length) return null;

    const segments = [];
    phrases.forEach((el) => {
      const tsAttr = el.getAttribute('data-ts') || el.getAttribute('data-start');
      if (tsAttr === null) return;
      const start = parseFloat(tsAttr);
      const text = el.textContent.trim();
      if (!isNaN(start) && text) {
        segments.push({ start, end: start + 5, text });
      }
    });

    segments.sort((a, b) => a.start - b.start);
    for (let i = 0; i < segments.length - 1; i++) {
      segments[i].end = segments[i + 1].start;
    }
    return segments.length > 0 ? segments : null;
  }

  /**
   * Udemy transcript panel: entries with class containing "transcript--cue"
   * and a sibling/child timestamp (MM:SS) element.
   */
  /**
   * Udemy hides timestamps in the transcript panel DOM. We try, in order:
   *   1. Fetch the VTT file (discovered via <track>, performance entries,
   *      or inline JSON) — exact timestamps.
   *   2. Read cue text from the transcript panel and distribute timestamps
   *      evenly across the video duration — approximate but usable.
   */
  async function extractFromUdemyDOM() {
    // ── 1. Try to find and fetch the VTT ────────────────────────────
    const vttUrls = new Set();

    document.querySelectorAll('track[src]').forEach((t) => t.src && vttUrls.add(t.src));

    if (performance?.getEntriesByType) {
      performance.getEntriesByType('resource').forEach((entry) => {
        if (/\.vtt(\?|$)/i.test(entry.name)) vttUrls.add(entry.name);
      });
    }

    const html = document.documentElement.outerHTML;
    const vttMatches = html.match(/https?:\\?\/\\?\/[^"'\s]+\.vtt[^"'\s]*/gi);
    if (vttMatches) {
      vttMatches.forEach((u) =>
        vttUrls.add(u.replace(/\\u002F/gi, '/').replace(/\\\//g, '/'))
      );
    }

    // Filter out known non-caption VTTs (thumbnail sprites, chapter markers)
    for (const url of Array.from(vttUrls)) {
      if (/thumb-sprites|sprites|thumbnails|chapters/i.test(url)) vttUrls.delete(url);
    }

    console.log(`[BridgeAI] Udemy: found ${vttUrls.size} candidate caption VTT URL(s)`);
    for (const url of vttUrls) {
      try {
        const resp = await fetch(url, { credentials: 'include' });
        if (!resp.ok) continue;
        const text = await resp.text();
        const segments = parseVTT(text);
        if (segments.length > 0) {
          console.log(`[BridgeAI] Udemy: parsed ${segments.length} VTT segments from ${url}`);
          return segments;
        }
      } catch (err) {
        console.warn(`[BridgeAI] Udemy: fetch failed for ${url}`, err);
      }
    }

    // ── 2. Fallback: transcript panel with evenly-distributed times ──
    const cueEls = document.querySelectorAll(
      '[data-purpose="transcript-panel"] [data-purpose^="transcript-cue"], ' +
      '[data-purpose="transcript-panel"] [class*="transcript--underline-cue"]'
    );
    if (!cueEls.length) return null;

    const texts = [];
    cueEls.forEach((el) => {
      const span = el.querySelector('[data-purpose="cue-text"]') || el;
      const t = span.textContent.trim();
      if (t) texts.push(t);
    });
    if (texts.length === 0) return null;

    const duration = videoElement?.duration;
    if (!duration || !isFinite(duration) || duration <= 0) {
      console.warn('[BridgeAI] Udemy: no VTT found and video duration unknown — cannot infer timestamps. Play the video briefly so duration loads, then retry.');
      return null;
    }

    const perCue = duration / texts.length;
    console.log(`[BridgeAI] Udemy: no VTT — distributing ${texts.length} cues across ${duration.toFixed(1)}s (~${perCue.toFixed(2)}s each, APPROXIMATE)`);
    return texts.map((text, i) => ({
      start: i * perCue,
      end: (i + 1) * perCue,
      text,
    }));
  }

  async function extractFromDOM() {
    // Platform-specific first
    if (PLATFORM === 'coursera') {
      const courseraSegs = extractFromCourseraDOM();
      if (courseraSegs && courseraSegs.length > 0) {
        console.log(`[BridgeAI] Extracted ${courseraSegs.length} Coursera phrases`);
        return courseraSegs;
      }
    }
    if (PLATFORM === 'udemy') {
      const udemySegs = await extractFromUdemyDOM();
      if (udemySegs && udemySegs.length > 0) {
        console.log(`[BridgeAI] Extracted ${udemySegs.length} Udemy cues`);
        return udemySegs;
      }
    }

    // Approach A: Echo360's virtualized transcript list
    const transcriptList = document.querySelector('.transcript-list');
    if (transcriptList) {
      console.log('[BridgeAI] Found .transcript-list — scrolling to collect all entries...');
      const segments = await scrollAndCollectEcho360(transcriptList);
      if (segments && segments.length > 0) return segments;
    }

    // Approach B: Try dd[data-test-component="Content"] directly
    const ddEntries = document.querySelectorAll('dd[data-test-component="Content"]');
    if (ddEntries.length > 0) {
      console.log(`[BridgeAI] Found ${ddEntries.length} dd[data-test-component] entries`);
      const segments = parseEcho360Entries(ddEntries);
      if (segments.length > 0) return segments;
    }

    // Approach C: Generic fallback selectors
    const fallbackSelectors = [
      '.transcript-line',
      '[class*="transcript"] [class*="line"]',
      '[class*="transcript"] [class*="cue"]',
    ];
    for (const selector of fallbackSelectors) {
      const elements = document.querySelectorAll(selector);
      if (elements.length > 0) {
        const segments = [];
        elements.forEach((el) => {
          const startAttr =
            el.getAttribute('data-start') ||
            el.getAttribute('data-time') ||
            el.getAttribute('data-start-time');
          const text = el.textContent.trim();
          if (text && startAttr !== null) {
            const start = parseFloat(startAttr);
            segments.push({
              start,
              end: start + 5,
              text,
            });
          }
        });
        if (segments.length > 0) {
          console.log(`[BridgeAI] Extracted ${segments.length} segments from DOM (${selector})`);
          return segments;
        }
      }
    }

    return null;
  }

  /**
   * Parse Echo360 <dd> entries into segments.
   * title="8.41 min" → 8.41 * 60 = 504.6 seconds
   */
  function parseEcho360Entries(ddElements) {
    const segments = [];
    ddElements.forEach((dd) => {
      const titleAttr = dd.getAttribute('title'); // e.g. "8.41 min"
      if (!titleAttr) return;

      const minuteMatch = titleAttr.match(/([\d.]+)\s*min/);
      if (!minuteMatch) return;

      const startSec = parseFloat(minuteMatch[1]) * 60;
      const span = dd.querySelector('span[role="button"]') || dd.querySelector('span');
      const text = span ? span.textContent.trim() : dd.textContent.trim();

      if (text && !isNaN(startSec)) {
        segments.push({ start: startSec, end: startSec + 5, text });
      }
    });

    // Fix end times: each segment ends when the next one starts
    for (let i = 0; i < segments.length - 1; i++) {
      segments[i].end = segments[i + 1].start;
    }

    return segments;
  }

  /**
   * Scroll through the ReactVirtualized transcript list to collect
   * ALL entries (since only visible ones are in the DOM at any time).
   */
  async function scrollAndCollectEcho360(listEl) {
    const collected = new Map(); // key: title attr → avoid duplicates

    // The actually-scrollable element is .ReactVirtualized__Grid (the parent
    // of __innerScrollContainer), NOT the outer .transcript-list wrapper.
    // Setting scrollTop on the wrong element is a silent no-op, so we'd end
    // up capturing only the initially-rendered viewport (~first 30 min).
    const inner = listEl.querySelector('.ReactVirtualized__Grid__innerScrollContainer');
    const scrollContainer =
      inner?.parentElement ||
      listEl.querySelector('.ReactVirtualized__Grid') ||
      listEl;
    const totalHeight = parseInt(inner?.style.height || '0', 10);

    console.log('[BridgeAI] Echo360 scroll container:', {
      tag: scrollContainer.tagName,
      class: scrollContainer.className,
      totalHeight,
      clientHeight: scrollContainer.clientHeight,
      scrollable: scrollContainer.scrollHeight > scrollContainer.clientHeight,
    });

    if (totalHeight === 0) {
      // Fallback: just read what's currently visible
      const visible = listEl.querySelectorAll('dd[data-test-component="Content"]');
      return parseEcho360Entries(visible);
    }

    const harvest = (root) => {
      const entries = root.querySelectorAll
        ? root.querySelectorAll('dd[data-test-component="Content"]')
        : [];
      entries.forEach((dd) => {
        const title = dd.getAttribute('title');
        if (title && !collected.has(title)) {
          const span = dd.querySelector('span[role="button"]') || dd.querySelector('span');
          const text = span ? span.textContent.trim() : dd.textContent.trim();
          collected.set(title, text);
        }
      });
    };

    // MutationObserver catches virtualized rows as React renders them,
    // even if they appear between our scroll-and-sleep checks.
    const observer = new MutationObserver((mutations) => {
      for (const m of mutations) {
        m.addedNodes.forEach((node) => {
          if (node.nodeType !== 1) return;
          if (node.matches && node.matches('dd[data-test-component="Content"]')) {
            harvest(node.parentElement || listEl);
          } else {
            harvest(node);
          }
        });
      }
    });
    observer.observe(listEl, { childList: true, subtree: true });

    const viewportHeight = scrollContainer.clientHeight;
    const scrollStep = Math.max(1, Math.floor(viewportHeight * 0.5));
    const maxScrolls = Math.ceil(totalHeight / scrollStep) + 10;
    const settleMs = 250;
    const stableRoundsNeeded = 3;

    // Save original scroll position
    const originalScrollTop = scrollContainer.scrollTop;

    const scrollToAndSettle = async (top) => {
      scrollContainer.scrollTop = top;
      await sleep(settleMs);
      harvest(listEl);
    };

    try {
      // Downward pass: scroll top → bottom, collecting as we go.
      await scrollToAndSettle(0);
      let stableRounds = 0;
      let lastCount = collected.size;
      for (let i = 0; i < maxScrolls; i++) {
        const prevScroll = scrollContainer.scrollTop;
        await scrollToAndSettle(prevScroll + scrollStep);

        const atBottom = scrollContainer.scrollTop === prevScroll;
        if (collected.size === lastCount) {
          stableRounds++;
        } else {
          stableRounds = 0;
          lastCount = collected.size;
        }
        if (atBottom && stableRounds >= stableRoundsNeeded) break;
      }

      // Upward sweep from bottom to top — catches rows React skipped
      // rendering during the fast downward pass.
      const maxScrollTop = Math.max(0, totalHeight - viewportHeight);
      await scrollToAndSettle(maxScrollTop);
      stableRounds = 0;
      lastCount = collected.size;
      for (let i = 0; i < maxScrolls; i++) {
        const prevScroll = scrollContainer.scrollTop;
        await scrollToAndSettle(Math.max(0, prevScroll - scrollStep));

        const atTop = scrollContainer.scrollTop === prevScroll;
        if (collected.size === lastCount) {
          stableRounds++;
        } else {
          stableRounds = 0;
          lastCount = collected.size;
        }
        if (atTop && stableRounds >= stableRoundsNeeded) break;
      }
    } finally {
      observer.disconnect();
      scrollContainer.scrollTop = originalScrollTop;
    }

    console.log(`[BridgeAI] Collected ${collected.size} entries by scrolling`);

    // Convert collected entries to segments
    const segments = [];
    for (const [title, text] of collected) {
      const minuteMatch = title.match(/([\d.]+)\s*min/);
      if (!minuteMatch) continue;
      const startSec = parseFloat(minuteMatch[1]) * 60;
      if (text && !isNaN(startSec)) {
        segments.push({ start: startSec, end: startSec + 5, text });
      }
    }

    // Sort by start time
    segments.sort((a, b) => a.start - b.start);

    // Fix end times
    for (let i = 0; i < segments.length - 1; i++) {
      segments[i].end = segments[i + 1].start;
    }

    return segments;
  }

  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  /**
   * Strategy 3: Wait for TextTrack cues to load (they may arrive async).
   * Listens for both addtrack (new tracks appearing) and cuechange events.
   */
  function waitForTextTrackCues(video, timeoutMs) {
    return new Promise((resolve) => {
      const tracks = video.textTracks;
      if (!tracks) {
        resolve(null);
        return;
      }

      // Check immediately
      const immediate = extractFromTextTracks(video);
      if (immediate) {
        resolve(immediate);
        return;
      }

      const tryExtract = () => {
        const result = extractFromTextTracks(video);
        if (result) {
          cleanup();
          resolve(result);
        }
      };

      const cleanup = () => {
        tracks.removeEventListener('addtrack', onAddTrack);
        for (let i = 0; i < tracks.length; i++) {
          tracks[i].removeEventListener('cuechange', tryExtract);
        }
        clearTimeout(timer);
      };

      // Listen for new tracks being added (Echo360 may add them dynamically)
      const onAddTrack = () => {
        // Activate new tracks and listen for cues
        for (let i = 0; i < tracks.length; i++) {
          if (tracks[i].kind === 'captions' || tracks[i].kind === 'subtitles') {
            tracks[i].mode = 'hidden';
            tracks[i].addEventListener('cuechange', tryExtract);
          }
        }
        // Check immediately in case cues are already loaded
        tryExtract();
      };

      tracks.addEventListener('addtrack', onAddTrack);

      // Also listen on existing tracks
      for (let i = 0; i < tracks.length; i++) {
        tracks[i].mode = 'hidden';
        tracks[i].addEventListener('cuechange', tryExtract);
      }

      const timer = setTimeout(() => {
        cleanup();
        resolve(null);
      }, timeoutMs);
    });
  }

  /**
   * Strategy 4: Find and parse VTT track sources directly.
   * Echo360 loads captions as VTT files via <track> elements.
   */
  async function extractFromTrackElements(video) {
    const trackEls = video.querySelectorAll('track[src]');
    if (!trackEls.length) return null;

    for (const trackEl of trackEls) {
      const kind = trackEl.getAttribute('kind');
      if (kind !== 'captions' && kind !== 'subtitles') continue;

      try {
        const response = await fetch(trackEl.src);
        if (!response.ok) continue;

        const vttText = await response.text();
        const segments = parseVTT(vttText);
        if (segments.length > 0) {
          console.log(`[BridgeAI] Extracted ${segments.length} segments from VTT file`);
          return segments;
        }
      } catch (err) {
        console.warn('[BridgeAI] Failed to fetch track source:', err);
      }
    }
    return null;
  }

  /**
   * Parse a WebVTT string into segments.
   */
  function parseVTT(vttText) {
    const segments = [];
    const blocks = vttText.split(/\n\n+/);

    for (const block of blocks) {
      const lines = block.trim().split('\n');
      // Find the timestamp line (contains " --> ")
      const tsIndex = lines.findIndex((l) => l.includes(' --> '));
      if (tsIndex === -1) continue;

      const [startStr, endStr] = lines[tsIndex].split(' --> ');
      const start = parseVTTTime(startStr.trim());
      const end = parseVTTTime(endStr.trim().split(' ')[0]); // strip position metadata

      const text = lines
        .slice(tsIndex + 1)
        .join(' ')
        .replace(/<[^>]*>/g, '')
        .trim();

      if (text && !isNaN(start) && !isNaN(end)) {
        segments.push({ start, end, text });
      }
    }
    return segments;
  }

  function parseVTTTime(str) {
    const parts = str.split(':');
    if (parts.length === 3) {
      return (
        parseFloat(parts[0]) * 3600 +
        parseFloat(parts[1]) * 60 +
        parseFloat(parts[2])
      );
    } else if (parts.length === 2) {
      return parseFloat(parts[0]) * 60 + parseFloat(parts[1]);
    }
    return NaN;
  }

  /**
   * Main extraction: tries all strategies with debug logging.
   */
  // Emit a real extraction-progress tick so the side panel can replace the
  // creep timer with something grounded in actual work done.
  function reportExtraction(current, total) {
    try {
      chrome.runtime.sendMessage({ action: 'extractionProgress', current, total });
    } catch {}
  }

  async function extractTranscript(video) {
    console.log('[BridgeAI] Starting transcript extraction...');
    const TOTAL = 5;
    reportExtraction(1, TOTAL);

    // Strategy 1: TextTrack API
    console.log('[BridgeAI] Strategy 1: TextTrack API...');
    console.log('[BridgeAI]   video.textTracks.length:', video.textTracks?.length || 0);
    if (video.textTracks) {
      for (let i = 0; i < video.textTracks.length; i++) {
        const t = video.textTracks[i];
        console.log(`[BridgeAI]   Track ${i}: kind=${t.kind}, mode=${t.mode}, cues=${t.cues?.length || 0}, label=${t.label}`);
      }
    }
    let segments = extractFromTextTracks(video);
    reportExtraction(2, TOTAL);
    if (segments && segments.length > 0) {
      reportExtraction(TOTAL, TOTAL);
      return segments;
    }

    // Strategy 2: DOM scraping (Echo360 virtualized list + fallbacks)
    console.log('[BridgeAI] Strategy 2: DOM scraping...');
    segments = await extractFromDOM();
    reportExtraction(3, TOTAL);
    if (segments && segments.length > 0) {
      reportExtraction(TOTAL, TOTAL);
      return segments;
    }

    // Strategy 3: Parse VTT track sources directly
    console.log('[BridgeAI] Strategy 3: VTT track elements...');
    const trackEls = video.querySelectorAll('track[src]');
    console.log('[BridgeAI]   <track> elements found:', trackEls.length);
    segments = await extractFromTrackElements(video);
    reportExtraction(4, TOTAL);
    if (segments && segments.length > 0) {
      reportExtraction(TOTAL, TOTAL);
      return segments;
    }

    // Strategy 4: Wait for async cue loading (up to 5s)
    console.log('[BridgeAI] Strategy 4: Waiting for async cues (5s)...');
    segments = await waitForTextTrackCues(video, 5000);
    reportExtraction(TOTAL, TOTAL);
    if (segments && segments.length > 0) return segments;

    console.log('[BridgeAI] All strategies failed. Dumping page debug info...');
    dumpDebugInfo();
    return null;
  }

  /**
   * Dump useful debug info to console so we can identify the DOM structure.
   */
  function dumpDebugInfo() {
    // Log all iframes (Echo360 may use iframes)
    const iframes = document.querySelectorAll('iframe');
    console.log(`[BridgeAI] iframes on page: ${iframes.length}`);
    iframes.forEach((f, i) => console.log(`[BridgeAI]   iframe ${i}: src=${f.src}`));

    // Log video elements
    const videos = document.querySelectorAll('video');
    console.log(`[BridgeAI] video elements: ${videos.length}`);

    // Log elements with time-like patterns (MM:SS)
    const timePattern = /^\d{1,2}:\d{2}$/;
    let timeElements = 0;
    document.querySelectorAll('span, div, p').forEach((el) => {
      if (el.children.length === 0 && timePattern.test(el.textContent.trim())) {
        timeElements++;
        if (timeElements <= 5) {
          console.log(`[BridgeAI]   time el: <${el.tagName.toLowerCase()} class="${el.className}"> ${el.textContent.trim()}`);
          console.log(`[BridgeAI]     parent: <${el.parentElement?.tagName.toLowerCase()} class="${el.parentElement?.className}">`);
        }
      }
    });
    console.log(`[BridgeAI] Total time-pattern elements: ${timeElements}`);

    // Log elements with "transcript" in class or id
    document.querySelectorAll('[class*="transcript"], [id*="transcript"]').forEach((el) => {
      console.log(`[BridgeAI]   transcript el: <${el.tagName.toLowerCase()} class="${el.className}" id="${el.id}"> children=${el.children.length}`);
    });
  }

  // ── API Communication ─────────────────────────────────────────────

  /**
   * Send API request via background service worker to bypass CORS.
   * Content scripts run in the page origin (echo360.net.au), but the
   * service worker is not subject to CORS restrictions.
   */
  function apiRequest(url, body) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(
        { action: 'apiRequest', url, body },
        (response) => {
          if (chrome.runtime.lastError) {
            reject(new Error(chrome.runtime.lastError.message));
          } else if (response && response.error) {
            reject(new Error(response.error));
          } else {
            resolve(response.data);
          }
        }
      );
    });
  }

  async function translateSegments(segments, targetLang, apiUrl) {
    const batchSize = 50;
    const allTranslated = [];
    const total = Math.ceil(segments.length / batchSize);

    // Report the start so the sidepanel switches from creep-timer to real %
    try {
      chrome.runtime.sendMessage({
        action: 'translationProgress',
        current: 0,
        total,
      });
    } catch {}

    for (let i = 0; i < segments.length; i += batchSize) {
      const batch = segments.slice(i, i + batchSize);
      const batchIdx = Math.floor(i / batchSize) + 1;
      console.log(`[BridgeAI] Translating batch ${batchIdx}/${total}...`);

      const data = await apiRequest(`${apiUrl}/api/translate-segments`, {
        segments: batch,
        target_lang: targetLang,
      });
      allTranslated.push(...data.segments);

      try {
        chrome.runtime.sendMessage({
          action: 'translationProgress',
          current: batchIdx,
          total,
        });
      } catch {}
    }

    return allTranslated;
  }

  // ── Subtitle Overlay ──────────────────────────────────────────────

  function createOverlay(video) {
    removeOverlay();

    // Attach to the nearest positioned ancestor that contains the video,
    // or fall back to video.parentElement. Force position:relative so our
    // absolute overlay anchors correctly.
    // Find an ancestor (not the video itself) to attach to
    let container;
    if (PLATFORM === 'youtube') {
      // YouTube's player wrapper. .html5-video-player is the standard
      // container; fallback to #movie_player.
      container =
        video.closest('.html5-video-player') ||
        document.getElementById('movie_player') ||
        video.parentElement;
    } else {
      container =
        video.parentElement?.closest('[class*="video-player"]') ||
        video.parentElement?.closest('[class*="player"]') ||
        video.parentElement;
    }
    if (container === video) container = video.parentElement;

    if (!container) {
      console.warn('[BridgeAI] No container found for overlay');
      return;
    }

    const cs = window.getComputedStyle(container);
    if (cs.position === 'static') container.style.position = 'relative';

    overlayContainer = document.createElement('div');
    overlayContainer.className = 'bridgeai-subtitle-container';
    // Inline overrides so we beat site stylesheets
    const bottomPx =
      PLATFORM === 'udemy' ? '90px' :
      PLATFORM === 'coursera' ? '80px' :
      PLATFORM === 'youtube' ? '80px' :
      '60px';
    overlayContainer.style.cssText =
      'position:absolute;left:0;right:0;bottom:' + bottomPx +
      ';z-index:2147483647;pointer-events:none;display:none;flex-direction:column;align-items:center;gap:4px;padding:0 10%;';

    overlayEN = document.createElement('p');
    overlayEN.className = 'bridgeai-subtitle-en';

    overlayTranslated = document.createElement('p');
    overlayTranslated.className = 'bridgeai-subtitle-translated';

    overlayContainer.appendChild(overlayEN);
    overlayContainer.appendChild(overlayTranslated);

    container.appendChild(overlayContainer);
    console.log(
      `[BridgeAI] Overlay injected into <${container.tagName.toLowerCase()} class="${container.className}">`
    );
  }

  function removeOverlay() {
    if (overlayContainer && overlayContainer.parentElement) {
      overlayContainer.parentElement.removeChild(overlayContainer);
    }
    overlayContainer = null;
    overlayEN = null;
    overlayTranslated = null;
  }

  let lastShownIndex = -1;
  let syncRAF = null;

  function updateSubtitle() {
    if (!videoElement || !overlayContainer || !overlayVisible) return;

    const time = videoElement.currentTime;

    // Binary search for active segment (segments are sorted by start time)
    let activeIdx = -1;
    let lo = 0;
    let hi = translatedSegments.length - 1;

    while (lo <= hi) {
      const mid = (lo + hi) >>> 1;
      const seg = translatedSegments[mid];

      if (time >= seg.start && time < seg.end) {
        activeIdx = mid;
        break;
      } else if (time < seg.start) {
        hi = mid - 1;
      } else {
        lo = mid + 1;
      }
    }

    if (activeIdx !== lastShownIndex) {
      lastShownIndex = activeIdx;
      if (activeIdx >= 0) {
        const seg = translatedSegments[activeIdx];
        overlayEN.textContent = seg.text;
        overlayTranslated.textContent = seg.translation;
        overlayContainer.style.display = 'flex';
      } else {
        overlayContainer.style.display = 'none';
      }
    }
  }

  function subtitleLoop() {
    updateSubtitle();
    syncRAF = requestAnimationFrame(subtitleLoop);
  }

  function startSubtitleSync(video) {
    if (PLATFORM === 'udemy') {
      startUdemyCaptionWatcher();
      return;
    }
    // requestAnimationFrame is more reliable than timeupdate — works even
    // when players throttle or pause the timeupdate event.
    if (syncRAF) cancelAnimationFrame(syncRAF);
    syncRAF = requestAnimationFrame(subtitleLoop);
  }

  function normalizeCueText(s) {
    return s.replace(/\s+/g, ' ').trim().toLowerCase();
  }

  function startUdemyCaptionWatcher() {
    // Build lookup: normalized original text → translation
    const lookup = new Map();
    translatedSegments.forEach((s) => {
      lookup.set(normalizeCueText(s.text), s.translation);
    });

    const waitForContainer = () => {
      const container =
        document.querySelector('[class*="captions-display--captions-container"]') ||
        document.querySelector('[data-purpose="captions-cue-text"]')?.parentElement?.parentElement;
      if (container) {
        hookUdemyCaption(container, lookup);
        return;
      }
      setTimeout(waitForContainer, 500);
    };
    waitForContainer();
  }

  function hookUdemyCaption(captionContainer, lookup) {
    console.log('[BridgeAI] Watching Udemy caption container for changes');
    // Hide Udemy's native caption so only our bilingual overlay is visible
    if (!document.getElementById('bridgeai-hide-udemy-captions')) {
      const style = document.createElement('style');
      style.id = 'bridgeai-hide-udemy-captions';
      style.textContent =
        '[data-purpose="captions-cue-text"]{visibility:hidden!important;}';
      document.head.appendChild(style);
    }
    let lastText = '';
    const render = () => {
      if (!overlayContainer || !overlayVisible) return;
      const el = captionContainer.querySelector('[data-purpose="captions-cue-text"]');
      const raw = el ? el.textContent.trim() : '';

      if (raw === lastText) return;
      lastText = raw;

      if (!raw) {
        overlayContainer.style.display = 'none';
        return;
      }

      const key = normalizeCueText(raw);
      let translation = lookup.get(key);
      if (!translation) {
        for (const [k, v] of lookup) {
          if (k.startsWith(key) || key.startsWith(k)) {
            translation = v;
            break;
          }
        }
      }

      overlayEN.textContent = raw;
      overlayTranslated.textContent = translation || '';
      overlayContainer.style.display = 'flex';
    };

    render();
    const obs = new MutationObserver(render);
    obs.observe(captionContainer, {
      childList: true,
      characterData: true,
      subtree: true,
    });
  }

  // ── Video Detection ───────────────────────────────────────────────

  function findVideo() {
    // Prefer the largest video element with a non-zero duration — Coursera
    // and Udemy may render hidden preview videos alongside the main player.
    const videos = Array.from(document.querySelectorAll('video'));
    if (videos.length === 0) return null;
    if (videos.length === 1) return videos[0];

    const withDuration = videos.filter((v) => v.duration > 0 || v.readyState > 0);
    const pool = withDuration.length > 0 ? withDuration : videos;
    return pool.reduce((best, v) =>
      v.clientWidth * v.clientHeight > best.clientWidth * best.clientHeight ? v : best,
    pool[0]);
  }

  function waitForVideo(timeoutMs) {
    return new Promise((resolve) => {
      const existing = findVideo();
      if (existing) {
        resolve(existing);
        return;
      }

      const observer = new MutationObserver(() => {
        const video = findVideo();
        if (video) {
          observer.disconnect();
          clearTimeout(timer);
          resolve(video);
        }
      });

      observer.observe(document.body, { childList: true, subtree: true });

      const timer = setTimeout(() => {
        observer.disconnect();
        resolve(null);
      }, timeoutMs);
    });
  }

  // ── Toggle ────────────────────────────────────────────────────────

  function toggleOverlay() {
    overlayVisible = !overlayVisible;
    if (overlayContainer) {
      overlayContainer.style.display = overlayVisible ? 'flex' : 'none';
      if (overlayVisible) updateSubtitle();
    }
  }

  // ── Message Handler ───────────────────────────────────────────────

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === 'ping') {
      sendResponse({ ok: true });
      return;
    }

    // The content script runs in every frame (manifest "all_frames": true).
    // For actions that operate on the player, only the frame that hosts the
    // <video> (or our overlay) should reply — otherwise an empty ad iframe
    // races a fast {error: "No video element found"} reply and beats the
    // real frame, even though the real frame is still translating in the
    // background.
    if (
      message.action === 'translate' ||
      message.action === 'capture' ||
      message.action === 'toggle'
    ) {
      if (!findVideo() && !overlayContainer) return; // other frame will handle
    }

    if (message.action === 'translate') {
      handleTranslate(message.targetLang, message.apiUrl, message.segments)
        .then((result) => sendResponse(result))
        .catch((err) => sendResponse({ error: err.message }));
      return true; // async response
    }

    if (message.action === 'toggle') {
      toggleOverlay();
      sendResponse({ visible: overlayVisible });
    }

    if (message.action === 'capture') {
      handleCapture(message.targetLang, message.apiUrl, message.segments)
        .then((result) => sendResponse(result))
        .catch((err) => sendResponse({ error: err.message }));
      return true; // async response
    }
  });

  async function handleCapture(targetLang, apiUrl, providedSegments) {
    videoElement = findVideo() || (await waitForVideo(10000));
    if (!videoElement) return { error: 'No video element found on this page.' };

    // YouTube: same single backend call as Translate. process-course saves
    // the course, links it to the user, and kicks off study materials.
    if (PLATFORM === 'youtube') {
      try {
        chrome.runtime.sendMessage({ action: 'saveProgress' });
      } catch {}
      const result = await youtubeProcess(apiUrl, targetLang);
      if (result.error) return { error: result.error };
      // Render the overlay too so the user sees subtitles even when they
      // hit Save first without clicking Translate.
      createOverlay(videoElement);
      startSubtitleSync(videoElement);
      return {
        success: true,
        message: result.fromCache ? 'Saved (cached)' : 'Saved to dashboard',
      };
    }

    // Build the raw English segments for ingest. Order of preference:
    //   1) caller provided (Echo360 VTT path)
    //   2) cached raw segments from a previous extraction in this session
    //   3) cached translated segments (text_en) — covers Echo360 after Save
    //   4) fresh DOM extraction
    let segments = providedSegments;
    if (!segments || segments.length === 0) {
      if (cachedRawSegments && cachedRawSegments.length > 0 && cachedRawKey === location.href) {
        segments = cachedRawSegments;
      } else if (translatedSegments && translatedSegments.length > 0) {
        segments = translatedSegments.map((s) => ({
          start: s.start,
          end: s.end,
          text: s.text,
        }));
      } else if (PLATFORM === 'echo360') {
        return { error: 'Upload the VTT file from Echo360 first.' };
      } else {
        segments = await getRawSegments(providedSegments, videoElement);
      }
    } else {
      cachedRawSegments = segments;
      cachedRawKey = location.href;
    }
    if (!segments || segments.length === 0) {
      return { error: 'No transcript/captions available on this page.' };
    }

    const payload = {
      source: PLATFORM,
      source_url: location.href,
      title: document.title.trim(),
      target_lang: targetLang,
      segments,
    };

    // If we already translated (via Translate Subtitles button), send
    // the pre-translated subtitles so the backend skips Bedrock entirely.
    if (translatedCacheValid(targetLang)) {
      payload.subtitles = translatedSegments.map((s) => ({
        start_seconds: s.start,
        end_seconds: s.end,
        text_en: s.text,
        text_translated: s.translation,
      }));
    }

    try {
      chrome.runtime.sendMessage({ action: 'saveProgress' });
    } catch {}

    // Use a long-lived port so the service worker stays alive during
    // the (potentially 10-30s) Bedrock call. One-shot sendMessage
    // kills the port if the SW gets suspended mid-request.
    const response = await new Promise((resolve) => {
      const port = chrome.runtime.connect({ name: 'ingest' });
      port.onMessage.addListener((msg) => {
        resolve(msg);
        port.disconnect();
      });
      port.onDisconnect.addListener(() => {
        if (chrome.runtime.lastError) {
          resolve({ error: chrome.runtime.lastError.message });
        }
      });
      port.postMessage({
        action: 'ingest',
        url: `${apiUrl}/api/ingest-course`,
        body: payload,
      });
    });

    if (response && response.error) return { error: response.error };

    // Pull the translated subtitles out of the ingest response so a later
    // Translate Subtitles click skips the backend entirely and just renders
    // the overlay.
    const courseData = response && response.data;
    if (courseData && Array.isArray(courseData.subtitles) && courseData.subtitles.length > 0) {
      translatedSegments = courseData.subtitles.map((s) => ({
        start: s.start_seconds,
        end: s.end_seconds,
        text: s.text_en,
        translation: s.text_translated,
      }));
      rememberTranslatedSegments(targetLang);
    }

    return { success: true, message: 'Saved to dashboard' };
  }

  // Both YouTube buttons run the exact same pipeline the web app's
  // /course/youtube page runs when the user pastes a URL into the home form:
  //   1) POST /api/fetch-transcript → cached ProcessResponse OR raw segments
  //   2) POST /api/translate-segments in batches of 50
  //   3) POST /api/ingest-course with the translated subtitles → save +
  //      link + kick off study materials
  // The extension never reads captions from the YouTube page itself, only
  // its URL. Backend caches make the second click free.
  async function youtubeProcess(apiUrl, targetLang) {
    if (translatedCacheValid(targetLang)) {
      return { fromCache: true };
    }

    const TOTAL = 5;
    reportExtraction(1, TOTAL);

    // ── 1. fetch-transcript ───────────────────────────────────────
    let fetchData;
    try {
      fetchData = await apiRequest(`${apiUrl}/api/fetch-transcript`, {
        video_url: location.href,
        target_lang: targetLang,
      });
    } catch (err) {
      return { error: 'Failed to fetch YouTube transcript: ' + err.message };
    }
    reportExtraction(2, TOTAL);

    // Cache hit on the backend — already translated. Use it.
    if (fetchData && fetchData.cached && Array.isArray(fetchData.cached.subtitles)) {
      translatedSegments = fetchData.cached.subtitles.map((s) => ({
        start: s.start_seconds,
        end: s.end_seconds,
        text: s.text_en,
        translation: s.text_translated,
      }));
      rememberTranslatedSegments(targetLang);
      reportExtraction(TOTAL, TOTAL);
      return { fromCache: true, course: fetchData.cached };
    }

    if (!fetchData || !Array.isArray(fetchData.segments) || fetchData.segments.length === 0) {
      return { error: 'No transcript returned for this video.' };
    }
    const rawSegments = fetchData.segments.map((s) => ({
      start: s.start,
      end: s.end,
      text: s.text,
    }));
    cachedRawSegments = rawSegments;
    cachedRawKey = location.href;

    // ── 2. translate-segments (batched) ───────────────────────────
    const BATCH = 50;
    const batches = Math.ceil(rawSegments.length / BATCH);
    const translated = [];
    try {
      chrome.runtime.sendMessage({
        action: 'translationProgress',
        current: 0,
        total: batches,
      });
    } catch {}
    try {
      for (let i = 0; i < rawSegments.length; i += BATCH) {
        const batch = rawSegments.slice(i, i + BATCH);
        const out = await apiRequest(`${apiUrl}/api/translate-segments`, {
          segments: batch,
          target_lang: targetLang,
        });
        if (!out || !Array.isArray(out.segments)) {
          return { error: 'Translation response was malformed.' };
        }
        translated.push(...out.segments);
        try {
          chrome.runtime.sendMessage({
            action: 'translationProgress',
            current: Math.floor(i / BATCH) + 1,
            total: batches,
          });
        } catch {}
      }
    } catch (err) {
      return { error: 'Translation failed: ' + err.message };
    }
    reportExtraction(4, TOTAL);

    // ── 3. ingest-course (save + link + study materials) ──────────
    const subtitles = translated.map((t) => ({
      start_seconds: t.start,
      end_seconds: t.end,
      text_en: t.text,
      text_translated: t.translation,
    }));
    try {
      chrome.runtime.sendMessage({ action: 'saveProgress' });
    } catch {}

    // Long-lived port keeps the service worker alive in case ingest blocks
    // briefly on the cache write.
    const ingestResp = await new Promise((resolve) => {
      const port = chrome.runtime.connect({ name: 'ingest' });
      port.onMessage.addListener((msg) => {
        resolve(msg);
        port.disconnect();
      });
      port.onDisconnect.addListener(() => {
        if (chrome.runtime.lastError) {
          resolve({ error: chrome.runtime.lastError.message });
        }
      });
      port.postMessage({
        action: 'ingest',
        url: `${apiUrl}/api/ingest-course`,
        body: {
          source: 'youtube',
          source_url: fetchData.video_url || location.href,
          title: fetchData.title || document.title.trim(),
          target_lang: targetLang,
          subtitles,
        },
      });
    });
    if (ingestResp && ingestResp.error) {
      return { error: 'Save failed: ' + ingestResp.error };
    }

    translatedSegments = translated.map((t) => ({
      start: t.start,
      end: t.end,
      text: t.text,
      translation: t.translation,
    }));
    rememberTranslatedSegments(targetLang);
    reportExtraction(TOTAL, TOTAL);
    return { fromCache: false, course: ingestResp && ingestResp.data };
  }

  async function handleYouTubeTranslate(targetLang, apiUrl) {
    videoElement = findVideo() || (await waitForVideo(10000));
    if (!videoElement) return { error: 'No video element found on this page.' };

    const videoID = extractYouTubeID();
    if (!videoID) return { error: 'Could not detect YouTube video ID. Open a watch URL.' };

    // Hide YouTube's native captions so only our bilingual overlay shows.
    if (!document.getElementById('bridgeai-hide-yt-captions')) {
      const style = document.createElement('style');
      style.id = 'bridgeai-hide-yt-captions';
      style.textContent =
        '.ytp-caption-window-container,.caption-window{display:none!important;}';
      document.head.appendChild(style);
    }

    const result = await youtubeProcess(apiUrl, targetLang);
    if (result.error) return { error: result.error };

    createOverlay(videoElement);
    startSubtitleSync(videoElement);
    return {
      success: true,
      message: result.fromCache
        ? `${translatedSegments.length} subtitles ready (cached)`
        : `${translatedSegments.length} subtitles translated to ${targetLang}`,
    };
  }

  async function handleTranslate(targetLang, apiUrl, providedSegments) {
    if (PLATFORM === 'youtube') {
      return handleYouTubeTranslate(targetLang, apiUrl);
    }

    // Find video element
    videoElement = findVideo();
    if (!videoElement) {
      videoElement = await waitForVideo(10000);
    }
    if (!videoElement) {
      return { error: 'No video element found on this page.' };
    }

    // Already translated this lang for this URL? Just re-render the overlay.
    if (translatedCacheValid(targetLang)) {
      console.log('[BridgeAI] Reusing cached translation, skipping backend call');
      createOverlay(videoElement);
      startSubtitleSync(videoElement);
      return {
        success: true,
        message: `${translatedSegments.length} subtitles ready (cached)`,
      };
    }

    // Get raw segments — provided (Echo360 VTT), cached, or freshly extracted.
    let segments = providedSegments;
    if (!segments || segments.length === 0) {
      if (PLATFORM === 'echo360') {
        return { error: 'Upload the VTT file from Echo360.' };
      }
      segments = await getRawSegments(providedSegments, videoElement);
    } else {
      // Cache user-provided segments too (Echo360 VTT path) so a later Save
      // doesn't need the panel to re-send them.
      cachedRawSegments = segments;
      cachedRawKey = location.href;
    }
    if (!segments || segments.length === 0) {
      const hint = {
        youtube: 'Make sure the video has captions enabled.',
        echo360: 'Download the VTT file from Echo360 and upload it here.',
        coursera: 'Open the "Transcript" tab under the Coursera video.',
        udemy: 'Click the "Transcript" button in the Udemy player.',
        generic: 'Make sure captions or a transcript panel are visible.',
      }[PLATFORM];
      return { error: `No transcript/captions found. ${hint}` };
    }

    // Call backend API
    try {
      translatedSegments = await translateSegments(segments, targetLang, apiUrl);
      rememberTranslatedSegments(targetLang);
      console.log(`[BridgeAI] Got ${translatedSegments.length} translated segments (first: "${translatedSegments[0]?.translation?.slice(0, 40)}")`);
    } catch (err) {
      return { error: 'Translation failed: ' + err.message };
    }

    // Create overlay and start sync
    createOverlay(videoElement);
    startSubtitleSync(videoElement);

    return {
      success: true,
      message: `${translatedSegments.length} subtitles translated to ${targetLang}`,
    };
  }

  // ── Init ──────────────────────────────────────────────────────────

  console.log(`[BridgeAI] Content script loaded (platform: ${PLATFORM})`);
})();
