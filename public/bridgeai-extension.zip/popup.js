const languageSelect = document.getElementById('language');
const apiUrlInput = document.getElementById('apiUrl');
const translateBtn = document.getElementById('translateBtn');
const toggleBtn = document.getElementById('toggleBtn');
const statusEl = document.getElementById('status');

const { DEFAULT_API_BASE } = self.BRIDGE_CONFIG;

// Load saved settings
chrome.storage.sync.get(['targetLang', 'apiUrl'], (data) => {
  if (data.targetLang) languageSelect.value = data.targetLang;
  apiUrlInput.value = data.apiUrl || DEFAULT_API_BASE;
});

// Gate the action buttons on auth state — don't let users click into dead ends.
function renderAuth(auth) {
  const signedIn = !!(auth && auth.token && auth.user);
  translateBtn.disabled = !signedIn;
  toggleBtn.disabled = !signedIn;
  if (!signedIn) setStatus('Sign in on the BridgeAI web app to use the extension.', 'err');
  else if (statusEl.textContent.startsWith('Sign in')) setStatus('', '');
}

chrome.storage.local.get(['auth'], ({ auth }) => renderAuth(auth));
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.auth) renderAuth(changes.auth.newValue);
});

// Save on change
languageSelect.addEventListener('change', () => {
  chrome.storage.sync.set({ targetLang: languageSelect.value });
});

apiUrlInput.addEventListener('change', () => {
  chrome.storage.sync.set({ apiUrl: apiUrlInput.value });
});

function setStatus(text, type) {
  statusEl.textContent = text;
  statusEl.className = type === 'ok' ? 'status-ok' : type === 'err' ? 'status-err' : 'status-loading';
}

// Translate button
translateBtn.addEventListener('click', async () => {
  translateBtn.disabled = true;
  setStatus('Extracting transcript...', 'loading');

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    chrome.tabs.sendMessage(
      tab.id,
      {
        action: 'translate',
        targetLang: languageSelect.value,
        apiUrl: apiUrlInput.value,
      },
      (response) => {
        translateBtn.disabled = false;

        if (chrome.runtime.lastError) {
          setStatus('Error: Open an Echo360, Coursera, or Udemy lecture page, then reload.', 'err');
          return;
        }

        if (response && response.error) {
          setStatus('Error: ' + response.error, 'err');
        } else if (response && response.success) {
          setStatus(response.message || 'Subtitles ready!', 'ok');
        }
      }
    );
  } catch (err) {
    translateBtn.disabled = false;
    setStatus('Error: ' + err.message, 'err');
  }
});

// Toggle button
toggleBtn.addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  chrome.tabs.sendMessage(tab.id, { action: 'toggle' }, (response) => {
    if (chrome.runtime.lastError) {
      setStatus('Error: Open a supported lecture page (Echo360, Coursera, Udemy).', 'err');
      return;
    }
    if (response) {
      setStatus(response.visible ? 'Subtitles visible' : 'Subtitles hidden', 'ok');
    }
  });
});
