// Production URLs — shipped to anyone who clones this repo.
// For local development, create `config.local.js` next to this file
// (it's gitignored) and it will override these values. Example:
//
//   // config.local.js
//   self.BRIDGE_CONFIG = {
//     DEFAULT_API_BASE: 'http://localhost:8080',
//     DEFAULT_WEB_URL:  'http://localhost:3000',
//   };

self.BRIDGE_CONFIG = {
  DEFAULT_API_BASE: 'https://bridgeai-api-w58c.onrender.com',
  DEFAULT_WEB_URL: 'https://bridge-ai-frontend-phi.vercel.app',
};
