importScripts('config.js');
try { importScripts('config.local.js'); } catch { /* no local override */ }
const DEFAULT_API_BASE = self.BRIDGE_CONFIG.DEFAULT_API_BASE;

// Toolbar icon click opens BridgeAI as a detached window. Works in
// Arc, Brave, Edge, and Chrome — unlike chrome.sidePanel which Arc
// silently ignores.
const PANEL_WIDTH = 400;
const PANEL_HEIGHT = 680;
let panelWindowId = null;

chrome.action.onClicked.addListener(async () => {
  console.log('[BridgeAI] action clicked');
  // If the panel is already open, focus it instead of spawning a duplicate.
  if (panelWindowId !== null) {
    try {
      const existing = await chrome.windows.get(panelWindowId);
      if (existing) {
        await chrome.windows.update(panelWindowId, { focused: true });
        return;
      }
    } catch {
      panelWindowId = null;
    }
  }

  const win = await chrome.windows.create({
    url: chrome.runtime.getURL('sidepanel.html'),
    type: 'popup',
    width: PANEL_WIDTH,
    height: PANEL_HEIGHT,
  });
  panelWindowId = win.id;
});

chrome.windows.onRemoved.addListener((windowId) => {
  if (windowId === panelWindowId) panelWindowId = null;
});

// Set default settings on install
chrome.runtime.onInstalled.addListener(() => {
  chrome.storage.sync.get(['targetLang', 'apiUrl'], (data) => {
    const defaults = {};
    if (!data.targetLang) defaults.targetLang = 'Thai';
    if (!data.apiUrl) defaults.apiUrl = DEFAULT_API_BASE;

    if (Object.keys(defaults).length > 0) {
      chrome.storage.sync.set(defaults);
    }
  });

  console.log('[BridgeAI] Extension installed — defaults set.');
});

// Long-lived port for slow requests (transcript ingest → Bedrock
// translation can take 10-30s). Keeps the service worker alive for
// the duration of the request.
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'ingest') return;
  port.onMessage.addListener((msg) => {
    if (msg.action !== 'ingest') return;
    chrome.storage.local.get(['auth'], ({ auth }) => {
      const headers = { 'Content-Type': 'application/json' };
      if (auth && auth.token) headers['Authorization'] = `Bearer ${auth.token}`;
      fetch(msg.url, {
        method: 'POST',
        headers,
        body: JSON.stringify(msg.body),
      })
        .then(async (response) => {
          if (!response.ok) {
            const err = await response.json().catch(() => ({}));
            try {
              port.postMessage({ error: err.error || `API returned ${response.status}` });
            } catch {}
          } else {
            const data = await response.json();
            try {
              port.postMessage({ data });
            } catch {}
          }
        })
        .catch((err) => {
          try {
            port.postMessage({ error: err.message });
          } catch {}
        });
    });
  });
});

// Accept auth handoff from the BridgeAI web app. The `externally_connectable`
// field in manifest.json whitelists which origins can reach this listener.
chrome.runtime.onMessageExternal.addListener((message, sender, sendResponse) => {
  if (!message || message.type !== 'auth') {
    sendResponse({ ok: false, error: 'unknown message type' });
    return;
  }
  const { token, user } = message;
  if (!token || !user) {
    sendResponse({ ok: false, error: 'missing token or user' });
    return;
  }
  chrome.storage.local.set({ auth: { token, user } }, () => {
    console.log('[BridgeAI] Auth stored for', user.email || user.id, 'from', sender.origin);
    sendResponse({ ok: true });
  });
  return true; // async response
});

// Proxy API calls from content script to avoid CORS issues.
// Content scripts run in the page's origin (e.g. echo360.net.au),
// but the service worker is not subject to CORS.
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'logout') {
    chrome.storage.local.get(['auth', 'apiUrl'], ({ auth, apiUrl }) => {
      const base = apiUrl || DEFAULT_API_BASE;
      const headers = {};
      if (auth && auth.token) headers['Authorization'] = `Bearer ${auth.token}`;
      fetch(`${base}/auth/logout`, {
        method: 'POST',
        credentials: 'include',
        headers,
      })
        .catch(() => {})
        .finally(() => {
          chrome.storage.local.remove('auth', () => sendResponse({ ok: true }));
        });
    });
    return true;
  }

  if (message.action === 'storeAuth') {
    const { token, user } = message;
    if (!token || !user) {
      sendResponse({ ok: false, error: 'missing token or user' });
      return;
    }
    chrome.storage.local.set({ auth: { token, user } }, () => {
      console.log('[BridgeAI] Auth stored for', user.email || user.id);
      sendResponse({ ok: true });
    });
    return true;
  }

  if (message.action === 'apiRequest') {
    const { url, body } = message;

    chrome.storage.local.get(['auth'], ({ auth }) => {
      const headers = { 'Content-Type': 'application/json' };
      if (auth && auth.token) headers['Authorization'] = `Bearer ${auth.token}`;

      fetch(url, { method: 'POST', headers, body: JSON.stringify(body) })
        .then(async (response) => {
          if (!response.ok) {
            const err = await response.json().catch(() => ({}));
            sendResponse({ error: err.error || `API returned ${response.status}` });
          } else {
            const data = await response.json();
            sendResponse({ data });
          }
        })
        .catch((err) => {
          sendResponse({ error: err.message });
        });
    });

    return true; // async response
  }
});
