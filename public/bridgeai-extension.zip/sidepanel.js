const languageSelect = document.getElementById('language');
const apiUrlInput = document.getElementById('apiUrl');
const translateBtn = document.getElementById('translateBtn');
const uploadVttBtn = document.getElementById('uploadVttBtn');
const saveBtn = document.getElementById('saveBtn');
const toggleBtn = document.getElementById('toggleBtn');
const linkBtn = document.getElementById('linkBtn');
const accountBody = document.getElementById('accountBody');
const statusEl = document.getElementById('status');
const vttInput = document.getElementById('vttInput');
const chatEmpty = document.getElementById('chatEmpty');
const chatBox = document.getElementById('chatBox');
const chatMessages = document.getElementById('chatMessages');
const chatInput = document.getElementById('chatInput');
const chatSendBtn = document.getElementById('chatSendBtn');

// VTT cues parsed from the most recent upload — Echo360 Save reuses these
// so the user doesn't have to pick the file twice.
let lastVttSegments = null;

// ── VTT helpers ──────────────────────────────────────────────────
function readVttFile(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(new Error('Could not read file'));
    reader.readAsText(file);
  });
}

function parseVTTTime(str) {
  const parts = str.split(':');
  if (parts.length === 3) {
    return parseFloat(parts[0]) * 3600 + parseFloat(parts[1]) * 60 + parseFloat(parts[2]);
  }
  if (parts.length === 2) {
    return parseFloat(parts[0]) * 60 + parseFloat(parts[1]);
  }
  return NaN;
}

function parseVTT(text) {
  const segments = [];
  const blocks = text.split(/\r?\n\r?\n+/);
  for (const block of blocks) {
    const lines = block.trim().split(/\r?\n/);
    const tsIdx = lines.findIndex((l) => l.includes(' --> '));
    if (tsIdx === -1) continue;
    const [startStr, endStr] = lines[tsIdx].split(' --> ');
    const start = parseVTTTime(startStr.trim());
    const end = parseVTTTime(endStr.trim().split(' ')[0]);
    const cue = lines
      .slice(tsIdx + 1)
      // Drop NOTE/STYLE/REGION metadata lines (Echo360 emits NOTE CONF
      // confidence arrays after every cue, which would otherwise pollute
      // the translation text).
      .filter((l) => l && !/^(NOTE|STYLE|REGION)\b/.test(l))
      .join(' ')
      // Strip <v Speaker 0>, <c.colour>, etc. voice/cue tags
      .replace(/<[^>]*>/g, '')
      .trim();
    if (cue && !isNaN(start) && !isNaN(end)) {
      segments.push({ start, end, text: cue });
    }
  }
  return segments;
}

function pickVttFile() {
  return new Promise((resolve) => {
    vttInput.value = '';
    const onChange = () => {
      vttInput.removeEventListener('change', onChange);
      const f = vttInput.files && vttInput.files[0];
      resolve(f || null);
    };
    vttInput.addEventListener('change', onChange);
    vttInput.click();
  });
}

const { DEFAULT_API_BASE, DEFAULT_WEB_URL } = self.BRIDGE_CONFIG;

const LECTURE_URL_PATTERN = /youtube\.com\/watch|youtube\.com\/embed|youtube\.com\/shorts|youtu\.be\/|echo360\.|coursera\.org|udemy\.com/;

// The panel runs in its own detached window, so `currentWindow:true`
// would return the panel itself. Scan all normal browser windows for
// a supported lecture tab instead.
async function findLectureTab() {
  const tabs = await chrome.tabs.query({ windowType: 'normal' });
  const matching = tabs.filter((t) => t.url && LECTURE_URL_PATTERN.test(t.url));
  if (matching.length === 0) return null;
  return matching.find((t) => t.active) || matching[0];
}

// Inject content.js into a lecture tab if the passive content_scripts
// injection missed it (happens after every extension reload).
async function ensureContentScript(tab) {
  try {
    await chrome.tabs.sendMessage(tab.id, { action: 'ping' });
  } catch {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id, allFrames: true },
      files: ['content.js'],
    });
    await chrome.scripting.insertCSS({
      target: { tabId: tab.id, allFrames: true },
      files: ['styles.css'],
    });
  }
}

// ── Settings ─────────────────────────────────────────────────────
chrome.storage.sync.get(['targetLang', 'apiUrl'], (data) => {
  if (data.targetLang) languageSelect.value = data.targetLang;
  apiUrlInput.value = data.apiUrl || DEFAULT_API_BASE;
});

languageSelect.addEventListener('change', () => {
  chrome.storage.sync.set({ targetLang: languageSelect.value });
  refreshChatPanel();
});

apiUrlInput.addEventListener('change', () => {
  chrome.storage.sync.set({ apiUrl: apiUrlInput.value });
  refreshChatPanel();
});

// ── Account state ────────────────────────────────────────────────
let signedIn = false;
let onEcho360 = false;

function refreshActionButtons() {
  // Echo360 actions need a VTT first; everywhere else, signed-in is enough.
  const echoBlocked = onEcho360 && !lastVttSegments;
  translateBtn.disabled = !signedIn || echoBlocked;
  saveBtn.disabled = !signedIn || echoBlocked;
  toggleBtn.disabled = !signedIn;
}

function renderAccount(auth) {
  signedIn = !!(auth && auth.token && auth.user);
  if (signedIn) {
    accountBody.innerHTML = `<div class="email">${auth.user.email}</div>`;
    linkBtn.textContent = 'Sign out';
  } else {
    accountBody.innerHTML = '<span class="muted">Not signed in</span>';
    linkBtn.textContent = 'Sign in on web';
  }
  refreshActionButtons();
  if (!signedIn) setStatus('Sign in to use BridgeAI.', 'err');
  else if (statusEl.textContent === 'Sign in to use BridgeAI.') setStatus('', '');
  refreshChatPanel();
}

function loadAuth() {
  chrome.storage.local.get(['auth'], ({ auth }) => renderAccount(auth));
}

loadAuth();

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === 'local' && changes.auth) renderAccount(changes.auth.newValue);
});

linkBtn.addEventListener('click', () => {
  chrome.storage.local.get(['auth'], ({ auth }) => {
    if (auth && auth.token) {
      chrome.runtime.sendMessage({ action: 'logout' }, () => {
        chrome.storage.local.remove('auth');
      });
      return;
    }
    chrome.tabs.create({ url: `${DEFAULT_WEB_URL}/login?next=/link-extension` });
  });
});

// ── Status helpers ───────────────────────────────────────────────
function setStatus(text, type) {
  statusEl.textContent = text;
  statusEl.className =
    type === 'ok' ? 'status-ok' : type === 'err' ? 'status-err' : 'status-loading';
}

// ── Progress bar ─────────────────────────────────────────────────
const progressEl = document.getElementById('progress');
const progressLabel = document.getElementById('progressLabel');
const progressPct = document.getElementById('progressPct');
const progressFill = document.getElementById('progressFill');
let progressTimer = null;
let progressValue = 0;
let progressStages = [];

function renderProgress() {
  const pct = Math.floor(progressValue);
  progressPct.textContent = pct + '%';
  progressFill.style.width = pct + '%';
  progressEl.setAttribute('aria-valuenow', String(pct));
  const stage = progressStages.find((s) => pct < s.until) || progressStages[progressStages.length - 1];
  if (stage) progressLabel.textContent = stage.label;
}

function startProgress(stages) {
  stopProgress();
  progressStages = stages && stages.length ? stages : [{ until: 100, label: 'Working…' }];
  progressValue = 1;
  progressEl.classList.add('active');
  setStatus('', '');
  renderProgress();
  // No creep timer — progress is driven by real events:
  //   extractionProgress → 0–20%
  //   translationProgress → 20–90%
  //   saveProgress → 95%
  //   finishProgress() → 100%
}

function finishProgress() {
  if (progressTimer) {
    clearInterval(progressTimer);
    progressTimer = null;
  }
  progressValue = 100;
  renderProgress();
  setTimeout(() => {
    progressEl.classList.remove('active');
  }, 400);
}

function stopProgress() {
  if (progressTimer) {
    clearInterval(progressTimer);
    progressTimer = null;
  }
  progressEl.classList.remove('active');
  progressValue = 0;
}

// Real progress driven by the content-script batch loop. Kills the creep
// timer so batch events alone determine the bar position.
function setRealProgress(pct) {
  if (progressTimer) {
    clearInterval(progressTimer);
    progressTimer = null;
  }
  // Never go backwards (batches can arrive slightly out of order).
  progressValue = Math.max(progressValue, Math.min(95, pct));
  renderProgress();
}

chrome.runtime.onMessage.addListener((msg) => {
  if (!msg || !progressEl.classList.contains('active')) return;

  if (msg.action === 'extractionProgress') {
    const { current, total } = msg;
    if (!total) return;
    // 0–20% reserved for extraction stages.
    setRealProgress((current / total) * 20);
    return;
  }

  if (msg.action === 'translationProgress') {
    const { current, total } = msg;
    if (!total) return;
    // 20–90% reserved for batch translation.
    setRealProgress(20 + (current / total) * 70);
    return;
  }

  if (msg.action === 'saveProgress') {
    // 90–99% reserved for the ingest/save round-trip (no intermediate signal).
    setRealProgress(95);
    return;
  }
});

// ── Echo360 mode ─────────────────────────────────────────────────
// On Echo360 the transcript panel is virtualized so DOM scraping is
// unreliable. We expose an "Upload VTT" step instead; the parsed cues are
// then used by Translate Subtitles (overlay) AND Generate Contents (save +
// AI study materials). Backend caching makes the second action free if the
// first already ran (segments cached by content hash; course + study
// materials cached by video_id + target_lang).
function isEcho360Url(url) {
  return !!(url && /echo360\./i.test(url));
}

async function refreshLecturePlatform() {
  const tab = await findLectureTab();
  onEcho360 = isEcho360Url(tab && tab.url);
  uploadVttBtn.hidden = !onEcho360;
  refreshActionButtons();
  refreshChatPanel();
}

refreshLecturePlatform();
chrome.tabs.onActivated.addListener(refreshLecturePlatform);
chrome.tabs.onUpdated.addListener((_id, info) => {
  if (info.url || info.status === 'complete') refreshLecturePlatform();
});

// ── Upload VTT (Echo360) ─────────────────────────────────────────
// Just parses the file and stashes the cues — no backend call yet. The
// user then picks Translate Subtitles or Generate Contents (or both).
uploadVttBtn.addEventListener('click', async () => {
  uploadVttBtn.disabled = true;
  try {
    setStatus('Choose the VTT file downloaded from Echo360…', 'loading');
    const file = await pickVttFile();
    if (!file) {
      setStatus('VTT upload cancelled.', 'err');
      return;
    }

    let text;
    try {
      text = await readVttFile(file);
    } catch (err) {
      setStatus('Could not read file: ' + err.message, 'err');
      return;
    }

    const segments = parseVTT(text);
    if (segments.length === 0) {
      setStatus('No subtitle cues found in that file.', 'err');
      return;
    }

    lastVttSegments = segments;
    refreshActionButtons();
    setStatus(
      `Loaded ${segments.length} cues from ${file.name}. Pick Translate Subtitles or Generate Contents.`,
      'ok',
    );
  } finally {
    uploadVttBtn.disabled = false;
  }
});

// ── Translate ────────────────────────────────────────────────────
translateBtn.addEventListener('click', async () => {
  translateBtn.disabled = true;
  startProgress([
    { until: 30, label: 'Extracting transcript…' },
    { until: 70, label: 'Translating segments…' },
    { until: 100, label: 'Finalising subtitles…' },
  ]);

  try {
    const tab = await findLectureTab();
    if (!tab) {
      translateBtn.disabled = false;
      stopProgress();
      setStatus('Open a YouTube, Echo360, Coursera, or Udemy lecture tab first.', 'err');
      return;
    }

    if (isEcho360Url(tab.url) && !lastVttSegments) {
      translateBtn.disabled = false;
      stopProgress();
      setStatus('Upload the VTT file from Echo360 first.', 'err');
      return;
    }

    await ensureContentScript(tab);
    chrome.tabs.sendMessage(
      tab.id,
      {
        action: 'translate',
        targetLang: languageSelect.value,
        apiUrl: apiUrlInput.value,
        // Skip DOM scraping when we already have the parsed VTT.
        segments: isEcho360Url(tab.url) ? lastVttSegments : null,
      },
      (response) => {
        translateBtn.disabled = false;
        if (chrome.runtime.lastError) {
          stopProgress();
          setStatus('Could not reach the lecture page. Try reloading it.', 'err');
          return;
        }
        if (response && response.error) {
          stopProgress();
          setStatus('Error: ' + response.error, 'err');
        } else if (response && response.success) {
          finishProgress();
          setStatus(response.message || 'Subtitles ready!', 'ok');
        } else {
          stopProgress();
        }
      }
    );
  } catch (err) {
    translateBtn.disabled = false;
    stopProgress();
    setStatus('Error: ' + err.message, 'err');
  }
});

// ── Save to dashboard ────────────────────────────────────────────
saveBtn.addEventListener('click', async () => {
  saveBtn.disabled = true;
  startProgress([
    { until: 40, label: 'Capturing lecture…' },
    { until: 80, label: 'Translating segments…' },
    { until: 100, label: 'Generating contents…' },
  ]);
  try {
    const tab = await findLectureTab();
    if (!tab) {
      saveBtn.disabled = false;
      stopProgress();
      setStatus('Open a supported lecture page first.', 'err');
      return;
    }
    if (isEcho360Url(tab.url) && !lastVttSegments) {
      saveBtn.disabled = false;
      stopProgress();
      setStatus('Upload the VTT file from Echo360 first.', 'err');
      return;
    }
    await ensureContentScript(tab);
    chrome.tabs.sendMessage(
      tab.id,
      {
        action: 'capture',
        targetLang: languageSelect.value,
        apiUrl: apiUrlInput.value,
        // On Echo360 we feed the parsed VTT through so the content script
        // doesn't try to scrape the virtualized transcript panel.
        segments: isEcho360Url(tab.url) ? lastVttSegments : null,
      },
      (response) => {
        saveBtn.disabled = false;
        if (chrome.runtime.lastError) {
          stopProgress();
          setStatus('Could not reach the lecture page. Try reloading it.', 'err');
          return;
        }
        if (response && response.error) {
          stopProgress();
          setStatus('Error: ' + response.error, 'err');
        } else if (response && response.success) {
          finishProgress();
          setStatus('Saved to your dashboard. Contents are generating in the background.', 'ok');
          refreshChatPanel();
        } else {
          stopProgress();
        }
      }
    );
  } catch (err) {
    saveBtn.disabled = false;
    stopProgress();
    setStatus('Error: ' + err.message, 'err');
  }
});

// ── Toggle overlay ───────────────────────────────────────────────
toggleBtn.addEventListener('click', async () => {
  const tab = await findLectureTab();
  if (!tab) {
    setStatus('Open a supported lecture page (YouTube, Echo360, Coursera, Udemy).', 'err');
    return;
  }
  await ensureContentScript(tab);
  chrome.tabs.sendMessage(tab.id, { action: 'toggle' }, (response) => {
    if (chrome.runtime.lastError) {
      setStatus('Could not reach the lecture page. Try reloading it.', 'err');
      return;
    }
    if (response) setStatus(response.visible ? 'Subtitles visible' : 'Subtitles hidden', 'ok');
  });
});

// ── Chat ─────────────────────────────────────────────────────────
// Chat is only enabled once the lecture has been saved to the dashboard
// (because /api/chat needs a cached transcript to ground the answer).
// On panel open / tab change / lang change / sign-in we GET /api/course;
// if it returns 200 the chat box unlocks, otherwise the empty-state hint
// stays visible.

let chatHistory = [];
let chatActiveKey = null;       // `${tab.url}|${lang}` while chat is unlocked
let chatCheckSeq = 0;           // ignore stale /api/course replies on rapid tab switches
let chatInFlight = false;

function chatKey(tabUrl, lang) {
  return `${tabUrl}|${lang}`;
}

function resetChatThread() {
  chatHistory = [];
  chatMessages.innerHTML =
    '<div class="chat-empty-thread">Ask anything about this lecture.</div>';
}

function appendChatMessage(role, content) {
  // Strip the placeholder on first real message.
  const placeholder = chatMessages.querySelector('.chat-empty-thread');
  if (placeholder) placeholder.remove();

  const div = document.createElement('div');
  div.className = `chat-message ${role}`;
  div.textContent = content;
  chatMessages.appendChild(div);
  chatMessages.scrollTop = chatMessages.scrollHeight;
  return div;
}

function getAuth() {
  return new Promise((resolve) => chrome.storage.local.get(['auth'], (d) => resolve(d.auth || null)));
}

async function refreshChatPanel() {
  const lang = languageSelect.value;
  const base = (apiUrlInput.value || DEFAULT_API_BASE).replace(/\/$/, '');
  const tab = await findLectureTab();
  const seq = ++chatCheckSeq;

  if (!signedIn || !tab) {
    chatActiveKey = null;
    chatBox.hidden = true;
    chatEmpty.hidden = false;
    return;
  }

  const key = chatKey(tab.url, lang);
  // If we're already unlocked for this exact tab+lang, leave the thread alone.
  if (chatActiveKey === key) return;

  try {
    const auth = await getAuth();
    const headers = {};
    if (auth && auth.token) headers['Authorization'] = `Bearer ${auth.token}`;
    const url = `${base}/api/course?url=${encodeURIComponent(tab.url)}&lang=${encodeURIComponent(lang)}`;
    const res = await fetch(url, { headers });
    if (seq !== chatCheckSeq) return; // a newer refresh has already started

    if (res.ok) {
      chatActiveKey = key;
      resetChatThread();
      chatEmpty.hidden = true;
      chatBox.hidden = false;
    } else {
      chatActiveKey = null;
      chatBox.hidden = true;
      chatEmpty.hidden = false;
    }
  } catch {
    if (seq !== chatCheckSeq) return;
    chatActiveKey = null;
    chatBox.hidden = true;
    chatEmpty.hidden = false;
  }
}

async function sendChatMessage() {
  if (chatInFlight) return;
  const text = chatInput.value.trim();
  if (!text || !chatActiveKey) return;

  const tab = await findLectureTab();
  if (!tab) {
    appendChatMessage('error', 'Lost the lecture tab — switch back to it and try again.');
    return;
  }

  const lang = languageSelect.value;
  const base = (apiUrlInput.value || DEFAULT_API_BASE).replace(/\/$/, '');

  chatInput.value = '';
  chatInput.disabled = true;
  chatSendBtn.disabled = true;
  chatInFlight = true;

  chatHistory.push({ role: 'user', content: text });
  appendChatMessage('user', text);
  const loadingDiv = appendChatMessage('assistant loading', 'Thinking…');

  try {
    const auth = await getAuth();
    const headers = { 'Content-Type': 'application/json' };
    if (auth && auth.token) headers['Authorization'] = `Bearer ${auth.token}`;

    const res = await fetch(`${base}/api/chat`, {
      method: 'POST',
      headers,
      body: JSON.stringify({
        video_url: tab.url,
        target_lang: lang,
        messages: chatHistory,
      }),
    });

    loadingDiv.remove();

    if (!res.ok) {
      const err = await res.json().catch(() => ({}));
      appendChatMessage('error', err.error || `Chat failed (${res.status})`);
      chatHistory.pop(); // roll back the user turn so they can retry without it duplicating in history
    } else {
      const data = await res.json();
      const answer = (data && data.answer) || '(no response)';
      chatHistory.push({ role: 'assistant', content: answer });
      appendChatMessage('assistant', answer);
    }
  } catch (err) {
    loadingDiv.remove();
    appendChatMessage('error', err.message || 'Network error');
    chatHistory.pop();
  } finally {
    chatInFlight = false;
    chatInput.disabled = false;
    chatSendBtn.disabled = false;
    chatInput.focus();
  }
}

chatSendBtn.addEventListener('click', sendChatMessage);
chatInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendChatMessage();
  }
});
