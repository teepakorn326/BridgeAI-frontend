# BridgeAI — Bilingual Lecture Subtitles

Chrome extension that overlays **bilingual subtitles** (English + your language) on Echo360, Coursera, Udemy, and YouTube lecture videos. Captures transcripts from the player, translates via AWS Bedrock (Claude Sonnet 4), renders dual-line subtitles synced to playback.

Part of the [BridgeAI](https://bridge-ai-frontend-phi.vercel.app) project.

---

## Install (users)

### Option A — Chrome Web Store *(recommended)*

Coming soon. Submission under Google review. Once published, you'll be able to install with one click.

### Option B — Developer mode (available today)

1. Download the code:
   ```
   git clone https://github.com/<your-username>/bridgeai-extension.git
   ```
   Or download the ZIP from the GitHub repo and unzip it.

2. Open Chrome and go to [`chrome://extensions`](chrome://extensions).

3. Top-right corner → toggle **Developer mode** ON.

4. Click **Load unpacked** → choose the downloaded `bridgeai-extension` folder.

5. Pin the extension: click the puzzle-piece icon in the Chrome toolbar → pin **BridgeAI**.

6. Click the BridgeAI icon → a side panel opens → **Sign in on web**. This opens the BridgeAI web app; sign in with Google, then close the tab. The extension will pick up your session automatically.

7. Open any Echo360, Coursera, or Udemy lecture → click the BridgeAI icon → **Translate Subtitles** or **Save Lecture to Dashboard**.

Works in Chrome, Arc, Brave, and Edge.

---

## What it does

- **Live bilingual overlay**: Translates lecture captions into Thai, Chinese, Vietnamese, Indonesian, Japanese, Korean, Spanish, and more — rendered on top of the video in real time.
- **Save to dashboard**: One click captures the full lecture and saves it to your BridgeAI library at [bridge-ai-frontend-phi.vercel.app](https://bridge-ai-frontend-phi.vercel.app) with auto-generated summary, quiz, vocab, chat, and chapter navigation.
- **Multi-platform**: Works across Echo360 (AU/NZ university lecture capture), Coursera, Udemy, and YouTube using four transcript-capture strategies so you don't have to know which one your platform uses.

---

## Privacy

- Your BridgeAI login is stored in `chrome.storage.local` (browser-local, not synced to Google).
- Lecture transcripts are sent to the BridgeAI backend for translation and caching. No other data leaves your browser.
- The extension requests `activeTab`, `scripting`, `sidePanel`, and `storage` permissions. It only activates on supported lecture pages.

See [privacy-policy.md](privacy-policy.md) for the full statement.

---

## Developer setup

```
git clone https://github.com/<your-username>/bridgeai-extension.git
cd bridgeai-extension
```

To point the extension at a locally-running BridgeAI backend (instead of production), create `config.local.js` next to `config.js`:

```js
// config.local.js (gitignored)
self.BRIDGE_CONFIG = {
  DEFAULT_API_BASE: 'http://localhost:8080',
  DEFAULT_WEB_URL:  'http://localhost:3000',
};
```

Reload the extension in `chrome://extensions`. The local override takes precedence.

### File layout

| File | Purpose |
|---|---|
| `manifest.json` | MV3 manifest |
| `background.js` | Service worker — handles toolbar click, API proxy, auth storage |
| `content.js` | Runs on lecture pages; captures transcripts; renders bilingual overlay |
| `bridge.js` | Runs on the BridgeAI web app; pipes session JWT into the extension |
| `sidepanel.html` / `.js` | Main UI (detached popup) |
| `popup.html` / `.js` | Fallback UI (not used when sidePanel is available) |
| `config.js` | Production URLs — committed |
| `config.local.js` | Local override — gitignored |
| `styles.css` | Subtitle overlay styling |

### Supported lecture sites

Content script `matches` in [`manifest.json`](manifest.json):

- `*.echo360.net.au`, `*.echo360.org.au`, `*.echo360.com`
- `*.coursera.org`
- `*.udemy.com`

Bridge script `matches`:

- `localhost:3000`, `127.0.0.1:3000` (local dev)
- `*.vercel.app` (production frontend)

---

## License

MIT.
