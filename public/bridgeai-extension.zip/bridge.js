/**
 * BridgeAI web <-> extension bridge.
 *
 * Runs as a content script on the BridgeAI web app. Listens for
 * window.postMessage events tagged `source: "bridgeai-web"` and
 * forwards them to the background service worker via
 * chrome.runtime.sendMessage — which IS available to content scripts
 * even in browsers that strip `chrome.runtime` from regular pages
 * (e.g. Arc).
 */
(function () {
  'use strict';

  window.addEventListener('message', (event) => {
    if (event.source !== window) return;
    const data = event.data;
    if (!data || data.source !== 'bridgeai-web') return;

    if (data.type === 'auth') {
      chrome.runtime.sendMessage({ action: 'storeAuth', token: data.token, user: data.user }, (response) => {
        window.postMessage(
          {
            source: 'bridgeai-extension',
            type: 'auth-ack',
            requestId: data.requestId,
            ok: !!(response && response.ok),
            error: response && response.error,
          },
          '*'
        );
      });
    } else if (data.type === 'ping') {
      window.postMessage(
        {
          source: 'bridgeai-extension',
          type: 'pong',
          requestId: data.requestId,
        },
        '*'
      );
    }
  });

  // Announce presence so the web page can detect the extension without
  // needing to send a ping first.
  window.postMessage({ source: 'bridgeai-extension', type: 'ready' }, '*');
})();
